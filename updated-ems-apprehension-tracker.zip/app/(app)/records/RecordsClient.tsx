"use client";

import { useEffect, useState, useCallback } from "react";
import Link from "next/link";

type RecordRow = {
  id: number;
  year: number;
  placeOfApprehension: string | null;
  dateOfApprehension: string | null;
  docketNumber: string | null;
  status: string;
  createdAt: string;
  cenroOffice: { name: string };
  _count: { items: number };
  /** Sum of forest products + conveyances + equipment estimated values */
  estimatedValue: number;
  productsValue: number;
  conveyancesValue: number;
  equipmentValue: number;
};

function peso(n: number | null | undefined) {
  if (n == null || n === 0) return "—";
  return `₱${n.toLocaleString("en-PH", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
}

const STATUS_LABEL: Record<string, string> = {
  FOR_RESOLUTION: "For Donation",
  UNDER_ADJUDICATION: "For Appraisal",
  CONFISCATED: "Donated",
  DONATED: "Donated",
  RELEASED: "Donated",
  UNKNOWN: "For Appraisal",
};

export default function RecordsClient({
  initialQuery,
}: {
  initialQuery: Record<string, string | undefined>;
}) {
  const [records, setRecords] = useState<RecordRow[]>([]);
  const [total, setTotal] = useState(0);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  // Resolve the page size the form asked for
  const pageSizeParam = initialQuery.pageSize ?? "25";
  const pageSize =
    pageSizeParam === "all"
      ? 500
      : Math.min(500, Math.max(10, parseInt(pageSizeParam, 10) || 25));

  const loadPage = useCallback(
    async (p: number) => {
      setLoading(true);
      setError(null);

      try {
        const qs = new URLSearchParams();
        Object.entries(initialQuery).forEach(([k, v]) => {
          if (v) qs.set(k, v);
        });
        qs.set("page", String(p));
        qs.set("pageSize", pageSizeParam); // keep the original value ("all" or number)

        const data = await fetch(`/api/records?${qs}`).then((r) => r.json());
        if (data.error) throw new Error(data.error);

        setRecords(data.records);
        setTotal(data.total);
        setPage(data.page);
        setTotalPages(data.totalPages);
      } catch (e: any) {
        setError(e.message || "Failed to load records");
      } finally {
        setLoading(false);
      }
    },
    [initialQuery, pageSizeParam]
  );

  useEffect(() => {
    loadPage(1);
  }, [loadPage]);

  return (
    <div className="space-y-5">
      {error && (
        <p className="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-[14px] text-red-700 dark:border-red-900 dark:bg-red-950 dark:text-red-300">
          {error}
        </p>
      )}

      {/* Summary + pagination controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-[13px] text-[var(--muted)]">
        <span>
          {loading
            ? "Loading…"
            : `${total.toLocaleString()} record${total === 1 ? "" : "s"}`}
        </span>

        {totalPages > 1 && (
          <div className="flex items-center gap-2">
            <button
              type="button"
              disabled={page <= 1 || loading}
              onClick={() => loadPage(page - 1)}
              className="rounded-md border border-[var(--border)] px-3 py-1.5 disabled:opacity-40"
            >
              Prev
            </button>
            <span className="tabular-nums">
              Page {page} of {totalPages}
            </span>
            <button
              type="button"
              disabled={page >= totalPages || loading}
              onClick={() => loadPage(page + 1)}
              className="rounded-md border border-[var(--border)] px-3 py-1.5 disabled:opacity-40"
            >
              Next
            </button>
          </div>
        )}
      </div>

      {/* Table — horizontal scroll only; vertical scroll is the page (mobile-friendly) */}
      <div className="app-table-shell">
        <table className="w-full min-w-[640px] text-left text-[13px]">
          <thead className="border-b border-[var(--border)] text-[11px] font-semibold uppercase tracking-wide text-white">
              <tr>
                <th className="px-4 py-2.5 font-semibold">Year</th>
                <th className="px-4 py-2.5 font-semibold">Office</th>
                <th className="px-4 py-2.5 font-semibold">Date / Place</th>
                <th className="px-4 py-2.5 font-semibold">Items</th>
                <th className="px-4 py-2.5 font-semibold text-right">Est. value</th>
                <th className="px-4 py-2.5 font-semibold">Status</th>
                <th className="px-4 py-2.5 font-semibold">Docket No.</th>
                <th className="px-4 py-2.5 font-semibold">Created</th>
              </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id} className="border-b border-[var(--border)] last:border-0">
                <td className="px-4 py-2.5">{r.year}</td>
                <td className="px-4 py-2.5">{r.cenroOffice.name}</td>
                <td className="px-4 py-2.5">
                  <Link
                    href={`/records/${r.id}`}
                    className="text-[var(--accent)] hover:underline"
                  >
                    {r.placeOfApprehension || r.dateOfApprehension || "—"}
                  </Link>
                </td>
                <td className="px-4 py-2.5 text-[var(--muted)]">{r._count.items}</td>
                <td
                  className="px-4 py-2.5 text-right tabular-nums text-[var(--foreground)]"
                  title={[
                    r.productsValue
                      ? `Forest products: ${peso(r.productsValue)}`
                      : null,
                    r.conveyancesValue
                      ? `Conveyances: ${peso(r.conveyancesValue)}`
                      : null,
                    r.equipmentValue
                      ? `Equipment: ${peso(r.equipmentValue)}`
                      : null,
                  ]
                    .filter(Boolean)
                    .join(" · ") || undefined}
                >
                  {peso(r.estimatedValue)}
                </td>
                <td className="px-4 py-2.5">
                  {STATUS_LABEL[r.status] ?? r.status}
                </td>
                <td className="px-4 py-2.5 text-[var(--muted)]">
                  {r.docketNumber || "—"}
                </td>
                <td className="px-4 py-2.5 text-[var(--muted)] whitespace-nowrap">
                  {r.createdAt
                    ? new Date(r.createdAt).toLocaleDateString("en-PH", {
                        year: "numeric",
                        month: "short",
                        day: "numeric",
                      })
                    : "—"}
                </td>
              </tr>
            ))}

            {!loading && records.length === 0 && (
              <tr>
                <td
                  colSpan={8}
                  className="px-4 py-12 text-center text-[var(--muted)]"
                >
                  No records found.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}