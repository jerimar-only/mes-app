import Link from "next/link";
import { prisma } from "@/lib/prisma";
import { buildRecordWhere } from "@/lib/recordFilters";
import { getOfficeScope } from "@/lib/officeScope";

const STATUS_LABEL: Record<string, string> = {
  FOR_RESOLUTION: "For resolution",
  UNDER_ADJUDICATION: "Under adjudication",
  CONFISCATED: "Confiscated",
  DONATED: "Donated",
  RELEASED: "Released",
  UNKNOWN: "Needs review",
};

// Labels for the filters that come from the dashboard links
const ACP_LABEL: Record<string, string> = {
  penro: "ACP endorsed to PENRO",
  ro: "ACP endorsed to Region",
  todo: "ACP to be conducted",
};

const PAGE_SIZE_OPTIONS = [25, 50, 100, 500] as const;

const dash = (v: string | number | null | undefined) =>
  v === null || v === undefined || v === "" ? "—" : String(v);

const fmtDate = (d: Date | null) =>
  d
    ? d.toLocaleDateString("en-US", { year: "numeric", month: "long", day: "numeric", timeZone: "UTC" })
    : null;

const peso = (n: number | null | undefined) => {
  if (n == null || n === 0) return "—";
  return `₱${n.toLocaleString("en-PH", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
};

function paramOne(value: string | string[] | undefined): string | undefined {
  if (value == null) return undefined;
  const s = Array.isArray(value) ? value[0] : value;
  const t = s?.trim();
  return t ? t : undefined;
}

export default async function FullRecordsPage({
  searchParams,
}: {
  searchParams: Promise<Record<string, string | string[] | undefined>>;
}) {
  const raw = await searchParams;
  const scope = await getOfficeScope();
  const params = {
    q: paramOne(raw.q),
    year: paramOne(raw.year),
    office:
      scope?.isCenro && scope.officeId
        ? String(scope.officeId)
        : paramOne(raw.office),
    status: paramOne(raw.status),
    deleted: paramOne(raw.deleted),
    acp: paramOne(raw.acp),
    conv: paramOne(raw.conv),
    resolved: paramOne(raw.resolved),
    page: paramOne(raw.page),
    pageSize: paramOne(raw.pageSize),
  };
  const isCenro = Boolean(scope?.isCenro);
  const page = Math.max(1, parseInt(params.page ?? "1", 10) || 1);

  // Parse pageSize — allowed: 25, 50, 100, 500
  let pageSize = 25;
  const parsed = parseInt(params.pageSize ?? "25", 10);
  if (PAGE_SIZE_OPTIONS.includes(parsed as any)) {
    pageSize = parsed;
  } else if (params.pageSize === "all") {
    // legacy URL support
    pageSize = 500;
  }

  const [offices, fieldDefs, yearRows] = await Promise.all([
    prisma.cenroOffice.findMany({ orderBy: { name: "asc" } }),
    prisma.fieldDefinition.findMany({ where: { disabled: false }, orderBy: { order: "asc" } }),
    prisma.apprehensionRecord.findMany({
      distinct: ["year"],
      select: { year: true },
      orderBy: { year: "desc" },
    }),
  ]);

  // Years come from the database (plus the selected one, so it never disappears)
  const years = [...new Set([...yearRows.map((r) => r.year), ...(params.year ? [parseInt(params.year, 10)] : [])])]
    .filter((y) => !Number.isNaN(y))
    .sort((a, b) => b - a);

  const where = buildRecordWhere(params);

  const [records, total] = await Promise.all([
    prisma.apprehensionRecord.findMany({
      where,
      include: {
        cenroOffice: true,
        items: true,
        conveyances: true,
        equipment: true,
        fieldValues: true,
      },
      orderBy: [{ year: "desc" }, { id: "desc" }],
      skip: (page - 1) * pageSize,
      take: pageSize,
    }),
    prisma.apprehensionRecord.count({ where }),
  ]);

  const totalPages = Math.max(1, Math.ceil(total / pageSize));
  const showingFrom = total === 0 ? 0 : (page - 1) * pageSize + 1;
  const showingTo = Math.min(page * pageSize, total);

  // Filters that came from the dashboard
  const activeChips: string[] = [];
  if (params.acp && ACP_LABEL[params.acp]) activeChips.push(ACP_LABEL[params.acp]);
  if (params.conv === "1") activeChips.push("With conveyance / chainsaw");
  if (params.resolved === "1") activeChips.push("Resolved cases");

  // Export link keeps every filter except paging
  const exportQs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v && k !== "page" && k !== "pageSize") exportQs.set(k, v);
  });

  return (
    <div className="space-y-5">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
        <p className="text-[14px] text-[var(--muted)]">
          Showing {showingFrom.toLocaleString()}–{showingTo.toLocaleString()} of{" "}
          {total.toLocaleString()} records
        </p>
        <div className="flex flex-wrap gap-2">
          <a
            href={`/records/full/export?${exportQs.toString()}`}
            className="inline-flex shrink-0 items-center rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-4 py-2 text-[14px] font-medium text-[var(--accent)] shadow-sm hover:bg-[var(--shell)]"
          >
            Export to Excel
          </a>
          <Link
            href={(() => {
              const back = new URLSearchParams();
              for (const key of ["q", "year", "office", "status", "deleted", "pageSize"] as const) {
                const v = params[key];
                if (v) back.set(key, v);
              }
              const s = back.toString();
              return s ? `/records?${s}` : "/records";
            })()}
            className="inline-flex shrink-0 items-center rounded-md border border-[var(--border-strong)] bg-[var(--card)] px-4 py-2 text-[14px] font-medium text-[var(--foreground)] shadow-sm transition hover:bg-[var(--shell)]"
          >
            ← Back to summary
          </Link>
        </div>
      </div>

      {/* Filters coming from the dashboard */}
      {activeChips.length > 0 && (
        <div className="flex flex-wrap items-center gap-2 text-[13px]">
          <span className="text-[var(--muted)]">Filtered by:</span>
          {activeChips.map((c) => (
            <span key={c} className="rounded-full bg-[var(--accent)] px-3 py-1 font-medium text-white">
              {c}
            </span>
          ))}
          <Link href="/records/full" className="text-[var(--accent)] underline">
            Clear all filters
          </Link>
        </div>
      )}

      {/* Filters */}
      <form
        method="get"
        className="flex flex-wrap items-end gap-2.5 rounded-lg border border-[var(--border)] bg-[var(--shell)] p-3"
      >
        {/* Keep the dashboard filters when pressing Apply */}
        {params.acp && <input type="hidden" name="acp" value={params.acp} />}
        {params.conv && <input type="hidden" name="conv" value={params.conv} />}
        {params.resolved && <input type="hidden" name="resolved" value={params.resolved} />}

        <div className="min-w-[200px] flex-1">
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Search
          </label>
          <input
            type="text"
            name="q"
            defaultValue={params.q}
            placeholder="Place, claimant, docket, remarks…"
            className="w-full rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          />
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Year
          </label>
          <select
            name="year"
            defaultValue={params.year ?? ""}
            className="rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          >
            <option value="">All</option>
            {years.map((y) => (
              <option key={y} value={y}>
                {y}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Office
          </label>
          <select
            name="office"
            defaultValue={params.office ? String(params.office) : ""}
            className="max-w-[160px] rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          >
            <option value="">All</option>
            {offices.map((o) => (
              <option key={o.id} value={String(o.id)}>
                {o.name}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Status
          </label>
          <select
            name="status"
            defaultValue={params.status ?? ""}
            className="rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          >
            <option value="">All</option>
            {Object.entries(STATUS_LABEL).map(([value, label]) => (
              <option key={value} value={value}>
                {label}
              </option>
            ))}
          </select>
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Records
          </label>
          <select
            name="deleted"
            defaultValue={params.deleted ?? ""}
            className="rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          >
            <option value="">Active</option>
            <option value="only">Deleted</option>
            <option value="all">Active + deleted</option>
          </select>
        </div>

        <div>
          <label className="mb-1 block text-[11px] font-medium uppercase tracking-wide text-[var(--muted)]">
            Per page
          </label>
          <select
            name="pageSize"
            defaultValue={params.pageSize ?? "25"}
            className="rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-2 text-[13px]"
          >
            <option value="25">25</option>
            <option value="50">50</option>
            <option value="100">100</option>
            <option value="500">500</option>
          </select>
        </div>

        <button
          type="submit"
          className="rounded-md bg-[var(--accent)] px-4 py-2 text-[13px] font-medium text-white hover:bg-[var(--accent-hover)]"
        >
          Apply
        </button>
      </form>

      {/* Table */}
      {/* max-height only on large screens so mobile uses normal page scroll */}
      <div className="app-table-shell relative lg:max-h-[70vh] lg:overflow-auto">
        <table className="w-full border-collapse text-left text-[12.5px]" style={{ minWidth: "2600px" }}>
          <thead className="sticky top-0 z-20 bg-[var(--accent)]">
            <tr className="border-b border-[var(--border)] bg-[var(--accent)] text-[11px] font-semibold uppercase tracking-wide text-white">
              {/* bg on every th so sticky header stays opaque in light + dark */}
              <th className="sticky left-0 z-30 whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white shadow-[2px_0_4px_-2px_rgba(0,0,0,0.08)]">
                ID
              </th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">CENRO office</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Year</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Month</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Date</th>
              <th className="min-w-[140px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Place</th>
              <th className="min-w-[140px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Source of products</th>
              <th className="min-w-[120px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">GPS</th>
              <th className="min-w-[110px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Land class.</th>
              <th className="min-w-[120px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Apprehending officers</th>
              <th className="min-w-[120px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Claimant/owner</th>
              <th className="min-w-[180px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Circumstances</th>
              <th className="min-w-[110px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Place impounded</th>
              <th className="min-w-[110px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Other agencies</th>
              <th className="min-w-[160px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Other remarks</th>
              <th className="min-w-[160px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Remarks</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">ACP to PENRO</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">ACP to RO</th>
              <th className="min-w-[220px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Case status</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Status</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Docket #</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Finality date</th>
              <th className="min-w-[150px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Forest products</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white text-right">Products value</th>
              <th className="min-w-[130px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Conveyances</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white text-right">Conveyances value</th>
              <th className="min-w-[130px] bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Equipment</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white text-right">Equipment value</th>
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white text-right">Total est. value</th>
              {fieldDefs.map((fd) => (
                <th key={fd.id} className="min-w-[120px] whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">
                  {fd.name}
                </th>
              ))}
              <th className="whitespace-nowrap bg-[var(--accent)] px-3 py-2.5 font-semibold text-white">Deleted</th>
            </tr>
          </thead>

          <tbody>
            {records.map((r, idx) => {
              const fvById = new Map(r.fieldValues.map((fv) => [fv.fieldDefinitionId, fv]));

              const productsText = r.items
                .map((it) => it.species || it.forms || it.description || "item")
                .join(", ");
              const conveyancesText = r.conveyances
                .map((c) => `${c.type} ×${c.quantity}`)
                .join(", ");
              const equipmentText = r.equipment
                .map((e) => `${e.type} ×${e.quantity}`)
                .join(", ");

              const productsValue = r.items.reduce(
                (s, i) => s + (i.estimatedValue ?? 0),
                0,
              );
              const conveyancesValue = r.conveyances.reduce(
                (s, c) => s + (c.estimatedValue ?? 0),
                0,
              );
              const equipmentValue = r.equipment.reduce(
                (s, e) => s + (e.estimatedValue ?? 0),
                0,
              );
              const totalEstimatedValue =
                productsValue + conveyancesValue + equipmentValue;

              const rowBg = idx % 2 === 0 ? "bg-[var(--card)] text-[var(--foreground)]" : "bg-[var(--shell)] text-[var(--foreground)]";

              return (
                <tr
                  key={r.id}
                  className={`border-b border-[var(--shell)] last:border-0 hover:bg-[var(--shell)] ${rowBg}`}
                >
                  {/* Sticky ID column */}
                  <td className={`sticky left-0 z-10 whitespace-nowrap px-3 py-2 font-medium shadow-[2px_0_4px_-2px_rgba(0,0,0,0.06)] ${rowBg}`}>
                    <Link href={`/records/${r.id}`} className="text-[var(--accent)] hover:underline">
                      {r.id}
                    </Link>
                  </td>

                  <td className="whitespace-nowrap px-3 py-2">{dash(r.cenroOffice.name)}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(r.year)}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(r.month)}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(r.dateOfApprehension)}</td>

                  {/* Wrapping cells */}
                  <td className="max-w-[180px] px-3 py-2 break-words leading-snug">{dash(r.placeOfApprehension)}</td>
                  <td className="max-w-[180px] px-3 py-2 break-words leading-snug">{dash(r.sourcePlace)}</td>
                  <td className="max-w-[140px] px-3 py-2 break-words leading-snug">{dash(r.gpsCoordinates)}</td>
                  <td className="max-w-[130px] px-3 py-2 break-words leading-snug">{dash(r.landClassification)}</td>
                  <td className="max-w-[140px] px-3 py-2 break-words leading-snug">{dash(r.apprehendingAgency)}</td>
                  <td className="max-w-[140px] px-3 py-2 break-words leading-snug">{dash(r.claimantRespondent)}</td>
                  <td className="max-w-[220px] px-3 py-2 break-words leading-snug">{dash(r.circumstances)}</td>
                  <td className="max-w-[130px] px-3 py-2 break-words leading-snug">{dash(r.custodianLocation)}</td>
                  <td className="max-w-[130px] px-3 py-2 break-words leading-snug">{dash(r.otherAgencies)}</td>
                  <td className="max-w-[200px] px-3 py-2 break-words leading-snug">{dash(r.otherRemarks)}</td>
                  <td className="max-w-[200px] px-3 py-2 break-words leading-snug">{dash(r.remarks)}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(fmtDate(r.acpEndorsedToPenro))}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(fmtDate(r.acpEndorsedToRo))}</td>
                  <td className="max-w-[260px] px-3 py-2 break-words leading-snug">{dash(r.caseStatus)}</td>

                  <td className="whitespace-nowrap px-3 py-2">{STATUS_LABEL[r.status] ?? r.status}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(r.docketNumber)}</td>
                  <td className="whitespace-nowrap px-3 py-2">{dash(r.orderOfFinalityDate)}</td>

                  <td className="max-w-[180px] px-3 py-2 break-words leading-snug">{dash(productsText)}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right tabular-nums">
                    {peso(productsValue)}
                  </td>
                  <td className="max-w-[150px] px-3 py-2 break-words leading-snug">{dash(conveyancesText)}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right tabular-nums">
                    {peso(conveyancesValue)}
                  </td>
                  <td className="max-w-[150px] px-3 py-2 break-words leading-snug">{dash(equipmentText)}</td>
                  <td className="whitespace-nowrap px-3 py-2 text-right tabular-nums">
                    {peso(equipmentValue)}
                  </td>
                  <td className="whitespace-nowrap px-3 py-2 text-right tabular-nums font-medium">
                    {peso(totalEstimatedValue)}
                  </td>

                  {fieldDefs.map((fd) => {
                    const fv = fvById.get(fd.id);
                    const value = !fv ? null : fd.type === "NUMBER" ? fv.numberValue : fv.textValue;
                    return (
                      <td key={fd.id} className="max-w-[140px] px-3 py-2 break-words leading-snug">
                        {dash(value)}
                      </td>
                    );
                  })}

                  <td className="whitespace-nowrap px-3 py-2">
                    {r.isDeleted ? (
                      <span className="rounded bg-red-50 px-1.5 py-0.5 text-[11px] font-medium text-red-700">
                        Yes
                      </span>
                    ) : (
                      "No"
                    )}
                  </td>
                </tr>
              );
            })}

            {records.length === 0 && (
              <tr>
                <td colSpan={30 + fieldDefs.length} className="px-4 py-12 text-center text-[14px] text-[var(--muted)]">
                  No records match these filters.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {/* Pagination */}
      {total > 0 && (
        <div className="flex flex-col items-center justify-between gap-3 text-[13px] text-[var(--muted)] sm:flex-row">
          <span>
            Page {page} of {totalPages}
            {totalPages > 1 && (
              <span className="ml-1 text-[#8B8B7A]">
                · {total.toLocaleString()} total
              </span>
            )}
          </span>

          {totalPages > 1 && (
            <div className="flex items-center gap-1.5">
              {page > 1 && <PageLink params={params} page={1} label="First" />}
              {page > 1 && <PageLink params={params} page={page - 1} label="← Prev" />}

              {Array.from({ length: Math.min(5, totalPages) }, (_, i) => {
                let p: number;
                if (totalPages <= 5) {
                  p = i + 1;
                } else if (page <= 3) {
                  p = i + 1;
                } else if (page >= totalPages - 2) {
                  p = totalPages - 4 + i;
                } else {
                  p = page - 2 + i;
                }
                return (
                  <PageLink
                    key={p}
                    params={params}
                    page={p}
                    label={String(p)}
                    active={p === page}
                  />
                );
              })}

              {page < totalPages && <PageLink params={params} page={page + 1} label="Next →" />}
              {page < totalPages && <PageLink params={params} page={totalPages} label="Last" />}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function PageLink({
  params,
  page,
  label,
  active = false,
}: {
  params: Record<string, string | undefined>;
  page: number;
  label: string;
  active?: boolean;
}) {
  const qs = new URLSearchParams();
  Object.entries(params).forEach(([k, v]) => {
    if (v && k !== "page") qs.set(k, v);
  });
  qs.set("page", String(page));

  return (
    <Link
      href={`/records/full?${qs.toString()}`}
      className={
        active
          ? "rounded-md bg-[var(--accent)] px-3 py-1.5 text-[13px] font-medium text-white"
          : "rounded-md border border-[var(--border-strong)] bg-[var(--card)] text-[var(--foreground)] px-3 py-1.5 text-[13px] hover:bg-[var(--shell)]"
      }
    >
      {label}
    </Link>
  );
}